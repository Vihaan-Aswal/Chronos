// src/pages/TeacherPage.jsx

import { useLocation, useSearchParams } from "react-router-dom";
import { useState, useRef, useEffect } from "react";

import useTeacherWebSocket from "../hooks/useTeacherWebSocket";
import NudgeButton from "../components/NudgeButton.jsx";
import HMSMeeting from "../hms/HMSMeeting.jsx";
import JoinScreen from "../components/JoinScreen.jsx";
import SessionReport from "../components/SessionReport.jsx";

export default function TeacherPage() {
  const location = useLocation();
  const [params] = useSearchParams();

  const user = location.state?.user;
  if (!user) {
    return (
      <div style={{ padding: 20 }}>
        ❌ No user found. Please login again.
      </div>
    );
  }

  const sessionId = params.get("sessionId") || "default-session";
  const userName = user.email;
  const teacherId = user.id;

  // Meeting state
  const [inMeeting, setInMeeting] = useState(false);
  const [sessionEnded, setSessionEnded] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [sessionData, setSessionData] = useState(null);

  // Track session start time and metrics
  const sessionStartRef = useRef(null);
  const metricsHistoryRef = useRef([]); // [{timestamp, avgScore, studentCount, students: {...}}]

  const { connected, students } = useTeacherWebSocket(sessionId);

  const studentArray = Object.entries(students).map(([uid, data]) => ({
    userId: uid,
    ...data,
  }));

  // Collect metrics every 30 seconds WITH DETAILED FACIAL DATA
  useEffect(() => {
    if (!inMeeting) return;
    if (studentArray.length === 0) return;

    const scores = studentArray.map(s => s.score || 0);
    const avgScore = scores.reduce((a, b) => a + b, 0) / scores.length;

    const studentSnapshot = {};
    studentArray.forEach(s => {
      studentSnapshot[s.userId] = {
        score: s.score || 0,
        strikes: s.strikes || 0,
        timestamp: s.timestamp,
        gazeDirection: s.gazeDirection || 'center',
        ear: s.ear || 0,
        headPose: s.headPose || { yaw: 0, pitch: 0 },
        presence: s.presence || 'unknown'
      };
    });

    metricsHistoryRef.current.push({
      timestamp: new Date().toISOString(),
      avgScore,
      studentCount: studentArray.length,
      students: studentSnapshot
    });
  }, [studentArray, inMeeting]);

  const statusColor = (score) => {
    if (score > 0.7) return "text-green-600";
    if (score >= 0.4) return "text-yellow-600";
    return "text-red-600";
  };

  const statusLabel = (score, strikes) => {
    if (strikes >= 3) return "Disengaged";
    if (score > 0.7) return "Attentive";
    if (score >= 0.4) return "Distracted";
    return "Away";
  };

  const handleJoinMeeting = () => {
    sessionStartRef.current = new Date();
    setInMeeting(true);
  };

  /**
   * CONFUSION DETECTION LOGIC
   * Confusion indicators from research:
   * - Low EAR (squinting: EAR < 0.28)
   * - Head tilt (yaw != 0, suggesting contemplation)
   * - Low engagement score (0.3-0.5 range = confused, not fully disengaged)
   */
  function detectConfusion(studentMetrics) {
    // A student is confused if:
    // 1. Score is in "confused range" (0.3 - 0.55)
    // 2. This indicates they're present but struggling
    const confusedRange = studentMetrics.score >= 0.3 && studentMetrics.score <= 0.55;
    return confusedRange;
  }

  /**
   * Analyze metrics timeline to find confusion hotspots
   * A hotspot is when >= 50% of class shows confusion
   */
  function findConfusionHotspots(metricsHistory) {
    const hotspots = [];
    
    metricsHistory.forEach((snapshot, idx) => {
      const studentData = snapshot.students || {};
      const studentIds = Object.keys(studentData);
      
      if (studentIds.length === 0) return;

      // Count confused students
      let confusedCount = 0;
      studentIds.forEach(uid => {
        const metrics = studentData[uid];
        if (detectConfusion(metrics)) {
          confusedCount++;
        }
      });

      const confusionPercentage = (confusedCount / studentIds.length) * 100;

      // If >= 50% are confused, it's a hotspot
      if (confusionPercentage >= 50) {
        hotspots.push({
          time: `${Math.floor(idx * 0.5)}m`,
          percentage: Math.round(confusionPercentage),
          studentCount: confusedCount,
          timestamp: snapshot.timestamp
        });
      }
    });

    return hotspots;
  }

  /**
   * Identify at-risk students (consistently low engagement)
   * Threshold: average score < 0.35 over the session
   */
  function identifyAtRiskStudents(metricsHistory, currentStudents) {
    const studentScores = {}; // uid -> [scores...]

    // Aggregate all scores per student
    metricsHistory.forEach(snapshot => {
      const studentData = snapshot.students || {};
      Object.entries(studentData).forEach(([uid, metrics]) => {
        if (!studentScores[uid]) studentScores[uid] = [];
        studentScores[uid].push(metrics.score);
      });
    });

    const atRisk = [];
    const AT_RISK_THRESHOLD = 0.35;

    Object.entries(studentScores).forEach(([uid, scores]) => {
      if (scores.length === 0) return;
      
      const avgScore = scores.reduce((a, b) => a + b, 0) / scores.length;
      
      if (avgScore < AT_RISK_THRESHOLD) {
        // Find strikes from current student data
        const studentInfo = currentStudents.find(s => s.userId === uid);
        atRisk.push({
          userId: uid,
          avgScore: avgScore,
          strikes: studentInfo?.strikes || 0
        });
      }
    });

    // Sort by lowest score first
    atRisk.sort((a, b) => a.avgScore - b.avgScore);

    return atRisk;
  }

  const handleLeaveMeeting = () => {
    // Mark session as ended 
    setSessionEnded(true);
    setInMeeting(false);

    const endTime = new Date();
    const startTime = sessionStartRef.current || endTime;
    const durationMinutes = (endTime - startTime) / 1000 / 60;

    // Calculate final metrics
    const scores = studentArray.map(s => s.score || 0);
    const avgScore = scores.length > 0 
      ? scores.reduce((a, b) => a + b, 0) / scores.length 
      : 0;

    // Calculate distribution
    const attentive = studentArray.filter(s => (s.score || 0) > 0.7).length;
    const distracted = studentArray.filter(s => (s.score || 0) >= 0.4 && (s.score || 0) <= 0.7).length;
    const disengaged = studentArray.filter(s => (s.score || 0) < 0.4).length;

    // Format metrics timeline for chart
    const metricsTimeline = metricsHistoryRef.current.map((m, idx) => ({
      time: `${Math.floor(idx * 0.5)}m`, // every 30s
      avgScore: Number(m.avgScore) || 0,
      students: m.studentCount || 0
    }));

    console.log("[ANALYTICS] Metrics Timeline:", metricsTimeline);

    // ANALYZE CONFUSION HOTSPOTS
    const confusionHotspots = findConfusionHotspots(metricsHistoryRef.current);

    // IDENTIFY AT-RISK STUDENTS
    const atRiskStudents = identifyAtRiskStudents(metricsHistoryRef.current, studentArray);

    const data = {
      sessionId,
      teacherId,
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      duration: durationMinutes,
      avgScore,
      totalStudents: studentArray.length,
      metricsTimeline,
      distribution: {
        attentive,
        distracted,
        disengaged
      },
      confusionHotspots,
      atRiskStudents
    };

    setSessionData(data);
    setShowReport(true);
  };

  const handleSaveReport = async () => {
    if (!sessionData) return;

    try {
      const response = await fetch(
        `${import.meta.env.VITE_BACKEND_URL}/session/save-analytics`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            session_id: sessionData.sessionId,
            teacher_id: sessionData.teacherId,
            start_time: sessionData.startTime,
            end_time: sessionData.endTime,
            duration_minutes: sessionData.duration,
            avg_engagement_score: sessionData.avgScore,
            total_students: sessionData.totalStudents,
            metrics_timeline: metricsHistoryRef.current,
            confusion_hotspots: sessionData.confusionHotspots,
            at_risk_students: sessionData.atRiskStudents
          })
        }
      );

      if (response.ok) {
        alert("Session report saved successfully! ✅");
        setShowReport(false);
        window.location.href = "/";
      } else {
        alert("Failed to save report. Please try again.");
      }
    } catch (error) {
      console.error("Error saving report:", error);
      alert("Error saving report. Check console.");
    }
  };

  const handleCloseReport = () => {
    setShowReport(false);
    window.location.href = "/";
  };

  // Before meeting -> show join UI (but NOT if session already ended)
  if (!inMeeting && !sessionEnded) {
    return (
      <JoinScreen
        user={user}
        onJoin={handleJoinMeeting}
      />
    );
  }

  return (
    <>
      {/* Only show meeting if inMeeting is true AND showReport is false */}
      {inMeeting && !showReport && (
        <div className="w-full h-screen flex bg-gray-100">
          <div className="flex-1 border-r relative bg-black">
            <HMSMeeting
              userName={userName}
              role="host"
              onLeave={handleLeaveMeeting}
            />

            {/* WebSocket indicator */}
            <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded shadow text-sm">
              {connected ? (
                <span className="text-green-600">🟢 WS Connected</span>
              ) : (
                <span className="text-red-600">🔴 WS Disconnected</span>
              )}
            </div>
          </div>

          {/* RIGHT – STUDENT ENGAGEMENT DASHBOARD */}
          <div className="w-[380px] bg-white h-full border-l overflow-y-auto">
            {/* HEADER */}
            <div className="p-4 border-b">
              <h1 className="text-2xl font-bold text-gray-900">
                Teacher Dashboard
              </h1>

              <p className="text-sm text-gray-600 mt-1">
                Session: <span className="font-mono">{sessionId}</span>
              </p>

              <p className="text-xs text-gray-500">
                Logged in as: {user.email}
              </p>
            </div>

            {/* STUDENT LIST */}
            <div className="p-4">
              <h2 className="text-lg font-semibold mb-3">
                Students ({studentArray.length})
              </h2>

              {studentArray.length === 0 ? (
                <div className="p-6 text-center border rounded text-gray-500">
                  Waiting for students...
                </div>
              ) : (
                <div className="space-y-4">
                  {studentArray.map((s) => (
                    <div
                      key={s.userId}
                      className={`p-4 border rounded shadow-sm ${
                        s.strikes >= 3 
                          ? "bg-red-50 border-red-400" 
                          : "bg-gray-50"
                      }`}
                    >
                      {/* TOP ROW */}
                      <div className="flex justify-between items-center">
                        <div className="font-semibold">
                          {s.userId.slice(0, 6)}...
                        </div>

                        {/* Manual teacher nudge */}
                        <NudgeButton
                          sessionId={sessionId}
                          userId={s.userId}
                        />
                      </div>

                      {/* SCORE + STATUS */}
                      <div className="mt-2 flex items-center gap-3">
                        <span
                          className={`text-3xl font-bold ${statusColor(
                            s.score
                          )}`}
                        >
                          {(s.score * 100).toFixed(0)}%
                        </span>

                        <span
                          className={`px-2 py-1 rounded text-sm font-semibold ${statusColor(
                            s.score
                          )} bg-opacity-20`}
                        >
                          {statusLabel(s.score, s.strikes)}
                        </span>
                      </div>

                      {/* TIME */}
                      <div className="mt-1 text-xs text-gray-600">
                        Last update:{" "}
                        {s.timestamp
                          ? new Date(s.timestamp).toLocaleTimeString()
                          : "—"}
                      </div>

                      {/* STRIKES */}
                      {s.strikes > 0 && (
                        <div className="text-xs text-red-600 mt-1">
                          ⚠ Strikes: {s.strikes}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SESSION REPORT MODAL*/}
      {showReport && sessionData && (
        <SessionReport
          sessionData={sessionData}
          onClose={handleCloseReport}
          onSave={handleSaveReport}
        />
      )}
    </>
  );
}