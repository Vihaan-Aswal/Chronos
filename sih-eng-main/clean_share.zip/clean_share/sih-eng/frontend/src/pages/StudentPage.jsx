// src/pages/StudentPage.jsx

import { useState, useRef } from "react";
import { useLocation } from "react-router-dom";

import JoinScreen from "../components/JoinScreen.jsx";
import EngagementTracker from "../components/EngagementTracker.jsx";
import NudgeNotification from "../components/NudgeNotification.jsx";
import HMSMeeting from "../hms/HMSMeeting.jsx";

export default function StudentPage() {
  const location = useLocation();
  const user = location.state?.user;

  if (!user) {
    return (
      <div style={{ padding: 20 }}>
        ❌ No user found. Please login again.
      </div>
    );
  }

  const userId = user.id;
  const sessionId = "default-session";
  const userName = user.email || userId;

  const [inMeeting, setInMeeting] = useState(false);

  const [nudgeMsg, setNudgeMsg] = useState(null);
  const nudgeTimeoutRef = useRef(null);

  const [showTracker, setShowTracker] = useState(true);

  const handleJoin = () => {
    setInMeeting(true);
  };

  const handleNudge = (msg) => {
    if (nudgeTimeoutRef.current) clearTimeout(nudgeTimeoutRef.current);

    const text =
      msg?.nudge_type === "hard"
        ? "Attention Required!"
        : "Please pay attention!";

    setNudgeMsg(text);

    nudgeTimeoutRef.current = setTimeout(() => setNudgeMsg(null), 3000);
  };

  if (!inMeeting) {
    return <JoinScreen user={user} onJoin={handleJoin} />;
  }

  return (
    <>
      <NudgeNotification message={nudgeMsg} />

      <div className="w-full h-screen flex overflow-hidden bg-gray-50">
        {/* LEFT SIDE — 100ms MEETING */}
        <div className="flex-1 bg-black relative overflow-hidden">
          <HMSMeeting
            userName={userName}
            role="guest"
            onLeave={() => window.location.reload()}
          />
        </div>

        {/* RIGHT SIDE — ENGAGEMENT */}
        {showTracker && (
          <div className="w-[420px] bg-white h-full border-l border-gray-200 overflow-y-auto shadow-2xl">
            <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-purple-600 text-white p-5 z-10 shadow-md">
              <h2 className="text-2xl font-bold mb-1">
                Engagement Monitor
              </h2>
              <p className="text-sm text-blue-100">
                Real-time attention tracking
              </p>
            </div>
            
            <div className="p-4">
              <EngagementTracker
                sessionId={sessionId}
                userId={userId}
                onNudge={handleNudge}
              />
            </div>
          </div>
        )}

        <button
          onClick={() => setShowTracker(!showTracker)}
          className="absolute top-4 left-4 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition shadow-lg flex items-center gap-2"
        >
          <span>{showTracker ? "⬅️" : "➡️"}</span>
          <span>{showTracker ? "Hide" : "Show"} Engagement</span>
        </button>
      </div>
    </>
  );
}