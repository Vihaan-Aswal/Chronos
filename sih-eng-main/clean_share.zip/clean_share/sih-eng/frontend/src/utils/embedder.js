// src/utils/embedder.js
import * as faceapi from "@vladmandic/face-api";

const MODEL_URL = "https://vladmandic.github.io/face-api/model/";

let loaded = false;

export async function loadEmbedder() {
  if (loaded) return;

  console.log("Loading face-api models...");

  await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);

  loaded = true;
  console.log("face-api model loaded!");
}

export async function getEmbedding(canvas112) {
  if (!loaded) throw new Error("Model not loaded");

  const descriptor = await faceapi.computeFaceDescriptor(canvas112);
  return descriptor; // Float32Array(128)
}
