import { useEffect, useRef, useState } from "react";

/**
 * Teacher WebSocket:
 * - Receives engagement metrics + auto-nudge responses
 * - Tracks all active students with detailed facial metrics
 */
export default function useTeacherWebSocket(sessionId) {
  const [connected, setConnected] = useState(false);
  const [students, setStudents] = useState({});
  const wsRef = useRef(null);
  const reconnectRef = useRef(null);

  useEffect(() => {
    if (!sessionId) return;
    let isMounted = true;

    function connect() {
      if (!isMounted) return;

      const wsUrl = `${
        import.meta.env.VITE_BACKEND_WS_URL
      }/ws/teacher/${sessionId}`;

      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          if (!isMounted) return;
          setConnected(true);
        };

        ws.onmessage = (event) => {
          if (!isMounted) return;

          try {
            const msg = JSON.parse(event.data);
            const uid = msg.user_id;
            if (!uid) return;

            setStudents(prev => {
              const prevStudent = prev[uid] || {};

              // --- TYPE handlers ---
              if (msg.type === "metrics") {
                return {
                  ...prev,
                  [uid]: {
                    ...prevStudent,
                    score: msg.score ?? prevStudent.score ?? 0,
                    timestamp: msg.timestamp || prevStudent.timestamp,
                    // Store facial metrics for confusion detection
                    gazeDirection: msg.gaze_direction || prevStudent.gazeDirection || 'center',
                    ear: msg.ear ?? prevStudent.ear ?? 0,
                    headPose: msg.head_pose || prevStudent.headPose || { yaw: 0, pitch: 0 },
                    presence: msg.presence || prevStudent.presence || 'unknown',
                  }
                };
              }

              if (msg.type === "auto_disengaged") {
                return {
                  ...prev,
                  [uid]: {
                    ...prevStudent,
                    strikes: msg.strike_count,
                    timestamp: msg.timestamp || prevStudent.timestamp,
                  }
                };
              }

              if (msg.type === "auto_disengaged_strike") {
                return {
                  ...prev,
                  [uid]: {
                    ...prevStudent,
                    strikes: msg.strike_count,
                    disengaged: true,          // <-- flag
                    timestamp: msg.timestamp || prevStudent.timestamp,
                  }
                };
              }

              if (msg.type === "nudge") {
                // manual nudge 
                return {
                  ...prev,
                  [uid]: {
                    ...prevStudent,
                    lastManualNudge: Date.now(),
                  }
                };
              }

              // fallback
              return {
                ...prev,
                [uid]: {
                  ...prevStudent,
                  ...msg,
                },
              };
            });

          } catch (err) {
            console.error("Teacher WS message error:", err);
          }
        };

        ws.onclose = () => {
          if (!isMounted) return;
          setConnected(false);
          wsRef.current = null;
          reconnectRef.current = setTimeout(connect, 2500);
        };

        ws.onerror = () => {
          if (!isMounted) return;
          setConnected(false);
        };
      } catch {
        reconnectRef.current = setTimeout(connect, 2500);
      }
    }

    connect();

    return () => {
      isMounted = false;
      if (reconnectRef.current) clearTimeout(reconnectRef.current);
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [sessionId]);

  return { connected, students };
}