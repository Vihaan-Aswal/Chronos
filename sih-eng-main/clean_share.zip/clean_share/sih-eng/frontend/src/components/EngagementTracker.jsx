// src/components/EngagementTracker.jsx
import { useEffect, useRef, useState } from "react";
import useWebSocket from "../hooks/useWebSocket";


function EngagementTracker({ sessionId, userId, onNudge }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  function computeEAR(landmarks, [upper, lower, inner, outer]) {
    if (!landmarks || landmarks.length === 0) return 0;
    if (!landmarks[upper] || !landmarks[lower] || !landmarks[inner] || !landmarks[outer]) return 0;
    const vertical = distance(landmarks[upper], landmarks[lower]);
    const horizontal = distance(landmarks[inner], landmarks[outer]);
    return horizontal > 0 ? vertical / horizontal : 0;
  }


  const gazeCalib = useRef({
    samples: [],
    centerAvg: 0.5,
    calibrated: false,
    smoothHoriz: 0.5,
    smoothVert: 0.3,
  }).current;

  const poseState = useRef({
    smoothYaw: 0,
    smoothPitch: 0,
    turned: false,
    lookingDown: false,
  }).current;

  const presenceState = useRef({ status: "unknown", bboxArea: 0 }).current;
  const engagementState = useRef({ score: 1, smoothScore: 1 }).current;

  const currentMetricsRef = useRef({
    gazeDirection: "center",
    ear: 0,
    headPose: { yaw: 0, pitch: 0 },
    presence: "unknown",
  });

  function gazeDirection(lm) {
    const LEFT_IRIS = 473, RIGHT_IRIS = 468;
    const LEFT_INNER = 263, LEFT_OUTER = 362;
    const RIGHT_INNER = 133, RIGHT_OUTER = 33;
    const [L_UP, L_DOWN] = [386, 374];
    const [R_UP, R_DOWN] = [159, 145];

    const horiz = ((lm[LEFT_IRIS].x - lm[LEFT_INNER].x) /
      (lm[LEFT_OUTER].x - lm[LEFT_INNER].x) +
      (lm[RIGHT_IRIS].x - lm[RIGHT_INNER].x) /
      (lm[RIGHT_OUTER].x - lm[RIGHT_INNER].x)) / 2;

    const down = ((lm[LEFT_IRIS].y - lm[L_UP].y) /
      (lm[L_DOWN].y - lm[L_UP].y) +
      (lm[RIGHT_IRIS].y - lm[R_UP].y) /
      (lm[R_DOWN].y - lm[R_UP].y)) / 2;

    gazeCalib.smoothHoriz = horiz;
    gazeCalib.smoothVert = down;

    if (!gazeCalib.calibrated) {
      gazeCalib.samples.push(horiz);
      if (gazeCalib.samples.length >= 25) {
        gazeCalib.centerAvg = 0.5;
        gazeCalib.calibrated = true;
      }
    }

    const c = gazeCalib.centerAvg;
    let dir = "center";
    if (down > 0.75) dir = "down";
    else if (horiz < c - 0.07) dir = "left";
    else if (horiz > c + 0.07) dir = "right";

    return { horizontal: horiz, vertical: down, direction: dir };
  }

  function estimateHeadPose(lm) {
    const nose = lm[1] ?? lm[4];
    const leftIris = lm[473];
    const rightIris = lm[468];
    const eyeMid = { x: (leftIris.x + rightIris.x) / 2, y: (leftIris.y + rightIris.y) / 2 };

    let minX = 1, minY = 1, maxX = 0, maxY = 0;
    for (let p of lm) {
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x);
      maxY = Math.max(maxY, p.y);
    }

    const faceW = maxX - minX || 1e-6;
    const faceH = maxY - minY || 1e-6;

    const yaw = (nose.x - (minX + maxX) / 2) / faceW;
    const pitch = (nose.y - eyeMid.y) / faceH;

    poseState.smoothYaw = poseState.smoothYaw * 0.75 + yaw * 0.25;
    poseState.smoothPitch = poseState.smoothPitch * 0.75 + pitch * 0.25;

    poseState.turned = Math.abs(poseState.smoothYaw) > 0.08;
    poseState.lookingDown = poseState.smoothPitch > 0.06;

    return {
      yaw: poseState.smoothYaw,
      pitch: poseState.smoothPitch,
      turned: poseState.turned,
      lookingDown: poseState.lookingDown,
    };
  }

  function checkPresence(lm) {
    if (!lm) {
      presenceState.status = "no_face";
      return presenceState;
    }
    let minX = 1, minY = 1, maxX = 0, maxY = 0;
    for (let p of lm) {
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x);
      maxY = Math.max(maxY, p.y);
    }

    const area = (maxX - minX) * (maxY - minY);
    presenceState.status = area > 0.0001 ? "present" : "no_face";
    return presenceState;
  }

  const scoreFromGaze = g => g.direction === "center" ? 1 : 0;
  const scoreFromHeadPose = p =>
    (!p.turned && !p.lookingDown) ? 1 :
      (p.turned && Math.abs(p.yaw) < 0.12) ? 0.6 : 0;
  const scoreFromPresence = p => p.status === "present" ? 1 : 0;
  const scoreFromEye = s =>
    s === "eyes_open" ? 1 :
      s === "blink" ? 0.9 :
        s === "closed_brief" ? 0.6 :
          s === "microsleep" ? 0.2 :
            0;

  const blinkData = useRef({
    lastEAR: 0,
    smoothEAR: 0,
    blinkStart: null,
    closedStart: null,
    status: "eyes_open",
  }).current;

  const leftEyeIdx = [386, 374, 263, 362];
  const rightEyeIdx = [159, 145, 133, 33];

  const OPEN_THRESHOLD = 0.32;
  const BLINK_THRESHOLD = 0.26;
  const CLOSED_THRESHOLD = 0.22;

  // Auto-nudge config 
  const WINDOW_MS = 15 * 1000; // 3 minutes rolling window
  const CHECK_INTERVAL = 15 * 1000; // check every 3 minutes
  const AUTO_THRESHOLD = 0.5; // trigger if average < 0.5
  const RESPONSE_WAIT_MS = 15 * 1000; // wait 15s for student response
  const MAX_STRIKES = 3;

  // Buffer to store {ts, score}
  const scoreBufferRef = useRef([]); // [{ts: number, score: 0..1}]
  const pendingAutoRef = useRef({ pending: false, timeoutId: null, responseResolver: null });
  const strikeCountRef = useRef(0);

  // WEBSOCKET SETUP 
  const wsUrl = sessionId && userId
    ? `${import.meta.env.VITE_BACKEND_WS_URL || "ws://localhost:8000"}/ws/engagement/${sessionId}/${userId}`
    : null;

  async function triggerAutoNudge(avgScore) {
    // if already pending, ignore
    if (pendingAutoRef.current.pending) return;

    pendingAutoRef.current.pending = true;
    console.log("[EngagementTracker] Auto-nudge triggered (avg)", avgScore);

    // Show modal 
    const response = await new Promise((resolve) => {

      pendingAutoRef.current.responseResolver = resolve;

      pendingAutoRef.current.timeoutId = setTimeout(() => {
        resolve({ type: "no_response" });
      }, RESPONSE_WAIT_MS);
      setAutoNudgeVisible(true);
    });

    // Hide modal 
    setAutoNudgeVisible(false);
    // clear timeout if still present
    if (pendingAutoRef.current.timeoutId) {
      clearTimeout(pendingAutoRef.current.timeoutId);
      pendingAutoRef.current.timeoutId = null;
    }
    pendingAutoRef.current.pending = false;
    pendingAutoRef.current.responseResolver = null;

    // Handle response
    if (response && response.type === "yes") {
      strikeCountRef.current += 1;  
      const strikes = strikeCountRef.current;

      send({
        type: "auto_nudge_response",
        session_id: sessionId,
        user_id: userId,
        response: "yes",
        timestamp: new Date().toISOString(),
        strike_count: strikes,
        score: Number(engagementState.smoothScore || 0),
      });

      scoreBufferRef.current = [];


      if (strikes >= MAX_STRIKES) {
        send({
          type: "auto_disengaged_strike",
          session_id: sessionId,
          user_id: userId,
          timestamp: new Date().toISOString(),
          strike_count: strikes,
          message: "Repeated disengagement",
          score: Number(engagementState.smoothScore || 0),
        });
      }

      return;
    }

    // no response or "no" 
    strikeCountRef.current += 1;
    const strikes = strikeCountRef.current;

    // send disengaged message to backend
    send({
      type: "auto_disengaged",
      session_id: sessionId,
      user_id: userId,
      timestamp: new Date().toISOString(),
      strike_count: strikes,
      avg_score: avgScore,
      score: Number(engagementState.smoothScore || 0)
    });
    scoreBufferRef.current = [];

    // if strikes >= MAX_STRIKES, send escalation
    if (strikes >= MAX_STRIKES) {
      send({
        type: "auto_disengaged_strike",
        session_id: sessionId,
        user_id: userId,
        timestamp: new Date().toISOString(),
        strike_count: strikes,
        message: "Repeated disengagement",
        score: Number(engagementState.smoothScore || 0)
      });
      scoreBufferRef.current = [];
    }
  }
  const handleMessage = (message) => {
    console.log("[EngagementTracker] Received WebSocket message:", message);
    if (message.type === "nudge") {
      // teacher manual nudge = trigger auto modal
      const avg = engagementState?.smoothScore || 0;
      triggerAutoNudge(avg);
    }

  };

  const { connected, send } = useWebSocket(wsUrl || "", handleMessage);

  // SEND METRICS INTERVAL
  useEffect(() => {
    if (!sessionId || !userId || !wsUrl) return;

    const interval = setInterval(() => {
      if (connected && engagementState && engagementState.smoothScore !== undefined) {
        const metrics = currentMetricsRef.current;
        send({
          type: "metrics",
          session_id: sessionId,
          user_id: userId,
          score: Number(engagementState.smoothScore || 0),
          timestamp: new Date().toISOString(),
          gaze_direction: metrics?.gazeDirection || "center",
          ear: metrics?.ear || 0,
          head_pose: metrics?.headPose || { yaw: 0, pitch: 0 },
          presence: metrics?.presence || "unknown",
        });
      }
    }, 3000); // every 3 seconds

    return () => clearInterval(interval);
  }, [connected, send, sessionId, userId, wsUrl]);

  // Periodic check for low engagement 
  useEffect(() => {
    if (!sessionId || !userId) return;
    let checkInterval = null;

    function computeAverageLastWindow() {
      const now = Date.now();
      const buffer = scoreBufferRef.current;

      while (buffer.length && buffer[0].ts < now - WINDOW_MS) buffer.shift();
      if (buffer.length === 0) return 1; // default high if no data
      const avg = buffer.reduce((s, it) => s + it.score, 0) / buffer.length;
      return avg;
    }



    // check immediately and then every CHECK_INTERVAL
    (async () => {
      const avg = computeAverageLastWindow();
      if (avg < AUTO_THRESHOLD) triggerAutoNudge(avg);
    })();

    checkInterval = setInterval(() => {
      const avg = computeAverageLastWindow();
      if (avg < AUTO_THRESHOLD) {
        triggerAutoNudge(avg);
      }
    }, CHECK_INTERVAL);

    return () => {
      if (checkInterval) clearInterval(checkInterval);
    };
  }, [sessionId, userId, send]);

  const [autoNudgeVisible, setAutoNudgeVisible] = useState(false);

  // Called by modal YES button
  function handleAutoNudgeYes() {
    if (pendingAutoRef.current && pendingAutoRef.current.responseResolver) {
      pendingAutoRef.current.responseResolver({ type: "yes" });
    }
  }



  // MAIN DETECT LOOP
  useEffect(() => {
    let stream = null;
    let loop = null;
    let faceLandmarker;
    let isMounted = true;

    async function init() {
      if (!isMounted) return;
      const vision = await import("@mediapipe/tasks-vision");
      const filesetResolver = await vision.FilesetResolver.forVisionTasks(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.4/wasm"
      );

      faceLandmarker = await vision.FaceLandmarker.createFromOptions(
        filesetResolver,
        {
          baseOptions: {
            modelAssetPath:
              "https://storage.googleapis.com/mediapipe-assets/face_landmarker_v2.task",
          },
          runningMode: "video",
          numFaces: 1,
        }
      );

      stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 720, height: 540 },
        audio: false,
      });

      videoRef.current.srcObject = stream;
      await videoRef.current.play();
      detect();
    }

    function detect() {
      if (!isMounted || !videoRef.current || !canvasRef.current) return;

      const results = faceLandmarker.detectForVideo(
        videoRef.current,
        performance.now()
      );

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (!results || !results.faceLandmarks) {
        presenceState.status = "no_face";
        engagementState.smoothScore = 0;

        // push low score into buffer 
        scoreBufferRef.current.push({ ts: Date.now(), score: 0 });

        currentMetricsRef.current = {
          ...currentMetricsRef.current,
          presence: "no_face",
          ear: 0,
          headPose: { yaw: 0, pitch: 0 }
        };

        ctx.fillStyle = "rgba(0,0,0,0.75)";
        ctx.fillRect(8, 8, 520, 240);
        ctx.fillStyle = "white";
        ctx.font = "28px system-ui, -apple-system, sans-serif";
        ctx.fillText(`Presence: no_face`, 28, 56);
        ctx.font = "bold 32px system-ui, -apple-system, sans-serif";
        ctx.fillText(
          `Score: ${Math.round((engagementState.smoothScore || 0) * 100)}%`,
          28, 110
        );

        if (isMounted) loop = requestAnimationFrame(detect);
        return;
      }

      const lm = results.faceLandmarks[0];
      if (!lm || lm.length === 0) {
        presenceState.status = "no_face";
        engagementState.smoothScore = 0;
        scoreBufferRef.current.push({ ts: Date.now(), score: 0 });

        currentMetricsRef.current = {
          ...currentMetricsRef.current,
          presence: "no_face",
          ear: 0,
          headPose: { yaw: 0, pitch: 0 }
        };

        ctx.fillStyle = "rgba(0,0,0,0.75)";
        ctx.fillRect(8, 8, 520, 240);
        ctx.fillStyle = "white";
        ctx.font = "28px system-ui, -apple-system, sans-serif";
        ctx.fillText(`Presence: no_face`, 28, 56);
        ctx.font = "bold 32px system-ui, -apple-system, sans-serif";
        ctx.fillText(
          `Score: ${Math.round((engagementState.smoothScore || 0) * 100)}%`,
          28, 110
        );

        if (isMounted) loop = requestAnimationFrame(detect);
        return;
      }

      const pres = checkPresence(lm);

      const leftEAR = computeEAR(lm, leftEyeIdx);
      const rightEAR = computeEAR(lm, rightEyeIdx);
      const EAR = (leftEAR + rightEAR) / 2;

      blinkData.smoothEAR = EAR * 0.8 + blinkData.smoothEAR * 0.2;
      const smooth = blinkData.smoothEAR;
      const now = performance.now();

      if (smooth > OPEN_THRESHOLD) {
        blinkData.status = "eyes_open";
        blinkData.blinkStart = null;
        blinkData.closedStart = null;
        blinkData.smoothEAR = smooth;
      } else if (smooth < BLINK_THRESHOLD && smooth > CLOSED_THRESHOLD) {
        if (!blinkData.blinkStart) blinkData.blinkStart = now;
        if (now - blinkData.blinkStart < 250) blinkData.status = "blink";
      } else if (smooth <= CLOSED_THRESHOLD) {
        if (!blinkData.closedStart) blinkData.closedStart = now;
        const duration = now - blinkData.closedStart;
        if (duration > 1000) blinkData.status = "closed_long";
        else if (duration > 400) blinkData.status = "microsleep";
        else blinkData.status = "closed_brief";
      }

      let gaze, pose;
      try {
        gaze = gazeDirection(lm);
        pose = estimateHeadPose(lm);
      } catch (error) {
        console.error("Error computing gaze/pose:", error);
        presenceState.status = "no_face";
        scoreBufferRef.current.push({ ts: Date.now(), score: 0 });
        if (isMounted) loop = requestAnimationFrame(detect);
        return;
      }

      const raw =
        scoreFromPresence(pres) * 0.3 +
        scoreFromGaze(gaze) * 0.25 +
        scoreFromHeadPose(pose) * 0.2 +
        scoreFromEye(blinkData.status) * 0.25;

      if (engagementState && engagementState.smoothScore !== undefined) {
        engagementState.smoothScore =
          engagementState.smoothScore * 0.85 + raw * 0.15;
      } else {
        engagementState.smoothScore = raw;
      }

      // push into rolling buffer
      scoreBufferRef.current.push({
        ts: Date.now(),
        score: Number(engagementState.smoothScore || 0)
      });
      
      if (gaze && pose && pres) {
        currentMetricsRef.current = {
          gazeDirection: gaze.direction || "center",
          ear: smooth || 0,
          headPose: { yaw: pose.yaw || 0, pitch: pose.pitch || 0 },
          presence: pres.status || "unknown",
        };
      }

      // MUCH LARGER OVERLAY TEXT
      ctx.fillStyle = "rgba(0,0,0,0.75)";
      ctx.fillRect(8, 8, 540, 260);
      ctx.fillStyle = "white";
      ctx.font = "28px system-ui, -apple-system, sans-serif";
      
      ctx.fillText(`Presence: ${pres.status}`, 28, 56);
      ctx.fillText(
        `Gaze: ${gaze.direction} (H:${gaze.horizontal.toFixed(2)})`,
        28, 100
      );
      ctx.fillText(
        `Head: yaw ${pose.yaw.toFixed(2)}`, 
        28, 144
      );
      ctx.fillText(
        `Eye: ${blinkData.status}`, 
        28, 188
      );
      
      // Score with VERY large, bold text and color
      ctx.font = "bold 36px system-ui, -apple-system, sans-serif";
      ctx.fillStyle = engagementState.smoothScore > 0.7 ? "#10b981" : 
                      engagementState.smoothScore > 0.4 ? "#f59e0b" : "#ef4444";
      ctx.fillText(
        `Score: ${Math.round(engagementState.smoothScore * 100)}%`,
        28, 240
      );

      if (isMounted) loop = requestAnimationFrame(detect);
    }

    init();

    return () => {
      isMounted = false;
      cancelAnimationFrame(loop);
      if (stream) stream.getTracks().forEach(t => t.stop());
    };
  }, []); // end main detect

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Live Tracking</h3>
        {wsUrl && (
          <div className="px-3 py-1 rounded-lg text-sm font-medium">
            {connected ? (
              <span className="text-green-600 bg-green-100 px-3 py-1.5 rounded-lg">🟢 Connected</span>
            ) : (
              <span className="text-red-600 bg-red-100 px-3 py-1.5 rounded-lg">🔴 Disconnected</span>
            )}
          </div>
        )}
      </div>

      <div className="relative w-full bg-black rounded-xl overflow-hidden shadow-lg" style={{ aspectRatio: "4/3" }}>
        <video ref={videoRef} style={{ display: "none" }} />
        <canvas
          ref={canvasRef}
          width={720}
          height={540}
          className="w-full h-full object-contain"
          style={{ position: "absolute", top: 0, left: 0 }}
        />
      </div>

      {/* AUTO-NUDGE MODAL */}
      {autoNudgeVisible && (
        <div style={{
          position: "fixed", left: 0, right: 0, top: 0, bottom: 0,
          display: "flex", alignItems: "center", justifyContent: "center",
          background: "rgba(0,0,0,0.5)", zIndex: 9999
        }}>
          <div style={{ background: "white", padding: 24, borderRadius: 12, width: 360, textAlign: "center" }}>
            <h3 style={{ marginBottom: 12, fontSize: 20, fontWeight: 600 }}>Quick check — are you focused?</h3>
            <p style={{ marginBottom: 20, color: "#444", fontSize: 15 }}>We detected low engagement recently. Tap YES if you are focused.</p>
            <div style={{ display: "flex", justifyContent: "center", gap: 12 }}>
              <button onClick={handleAutoNudgeYes} style={{ padding: "10px 20px", background: "#10b981", color: "white", borderRadius: 8, fontSize: 15, fontWeight: 600 }}>YES</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default EngagementTracker;