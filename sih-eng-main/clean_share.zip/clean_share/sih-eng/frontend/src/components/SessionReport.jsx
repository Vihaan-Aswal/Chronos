// src/components/SessionReport.jsx
import { LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function SessionReport({ 
  sessionData, 
  onClose, 
  onSave 
}) {
  const {
    duration,
    avgScore,
    totalStudents,
    metricsTimeline,
    distribution,
    confusionHotspots = [],
    atRiskStudents = []
  } = sessionData;

  const COLORS = {
    attentive: '#10b981',   
    distracted: '#f59e0b',  
    disengaged: '#ef4444'  
  };

  const pieData = [
    { name: 'Attentive', value: distribution.attentive, color: COLORS.attentive },
    { name: 'Distracted', value: distribution.distracted, color: COLORS.distracted },
    { name: 'Disengaged', value: distribution.disengaged, color: COLORS.disengaged }
  ];

  const formatTime = (minutes) => {
    const hrs = Math.floor(minutes / 60);
    const mins = Math.floor(minutes % 60);
    if (hrs > 0) return `${hrs}h ${mins}m`;
    return `${mins}m`;
  };

  const getScoreColor = (score) => {
    if (score >= 0.7) return 'text-green-600';
    if (score >= 0.4) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score) => {
    if (score >= 0.7) return 'Excellent';
    if (score >= 0.4) return 'Average';
    return 'Needs Improvement';
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="p-6 border-b bg-gradient-to-r from-blue-600 to-purple-600">
          <h2 className="text-2xl font-bold text-white mb-1">
            Session Complete! 🎉
          </h2>
          <p className="text-blue-100 text-sm">
            Here's how your class performed
          </p>
        </div>

        {/* Stats Cards */}
        <div className="p-6 grid grid-cols-3 gap-4">
          {/* Duration */}
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="text-sm text-blue-600 font-medium mb-1">Duration</div>
            <div className="text-3xl font-bold text-blue-700">
              {formatTime(duration)}
            </div>
          </div>

          {/* Average Score */}
          <div className={`bg-gray-50 rounded-lg p-4 border ${
            avgScore >= 0.7 ? 'border-green-200' : 
            avgScore >= 0.4 ? 'border-yellow-200' : 
            'border-red-200'
          }`}>
            <div className="text-sm text-gray-600 font-medium mb-1">Avg Engagement</div>
            <div className={`text-3xl font-bold ${getScoreColor(avgScore)}`}>
              {(avgScore * 100).toFixed(0)}%
            </div>
            <div className={`text-xs font-medium mt-1 ${getScoreColor(avgScore)}`}>
              {getScoreLabel(avgScore)}
            </div>
          </div>

          {/* Total Students */}
          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <div className="text-sm text-purple-600 font-medium mb-1">Students</div>
            <div className="text-3xl font-bold text-purple-700">
              {totalStudents}
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="px-6 pb-6 space-y-6">
          
          {/* Engagement Over Time */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">
              Engagement Timeline
            </h3>
            {metricsTimeline && metricsTimeline.length > 0 ? (
              <div className="bg-gray-50 rounded-lg p-4 border">
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={metricsTimeline}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis 
                      dataKey="time" 
                      stroke="#6b7280"
                      style={{ fontSize: '12px' }}
                    />
                    <YAxis 
                      stroke="#6b7280"
                      style={{ fontSize: '12px' }}
                      domain={[0, 1]}
                      ticks={[0, 0.25, 0.5, 0.75, 1]}
                      tickFormatter={(value) => `${(value * 100).toFixed(0)}%`}
                    />
                    <Tooltip 
                      formatter={(value, name) => {
                        if (name === "Class Average") {
                          return [`${(value * 100).toFixed(0)}%`, name];
                        }
                        return [value, name];
                      }}
                      contentStyle={{ 
                        backgroundColor: 'white',
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        fontSize: '12px'
                      }}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="avgScore" 
                      name="Class Average"
                      stroke="#3b82f6" 
                      strokeWidth={3}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="bg-gray-50 rounded-lg p-8 border text-center">
                <p className="text-gray-500">No timeline data available</p>
              </div>
            )}
          </div>

          {/* Distribution Pie Chart */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">
              Attention Distribution
            </h3>
            <div className="bg-gray-50 rounded-lg p-4 border">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              
              {/* Legend */}
              <div className="flex justify-center gap-6 mt-4">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: COLORS.attentive }} />
                  <span className="text-sm text-gray-700">Attentive (&gt;70%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: COLORS.distracted }} />
                  <span className="text-sm text-gray-700">Distracted (40-70%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: COLORS.disengaged }} />
                  <span className="text-sm text-gray-700">Disengaged (&lt;40%)</span>
                </div>
              </div>
            </div>
          </div>

          {/* CONFUSION HOTSPOTS */}
          {/* <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">
              Confusion Hotspots
            </h3>
            <div className="bg-gray-50 rounded-lg p-4 border">
              {confusionHotspots.length === 0 ? (
                <div className="text-center py-8">
                  <div className="text-5xl mb-2"></div>
                  <p className="text-gray-600 font-medium">No confusion hotspots detected!</p>
                  <p className="text-sm text-gray-500 mt-1">Students understood the material well</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {confusionHotspots.map((hotspot, idx) => (
                    <div key={idx} className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="font-semibold text-orange-900 mb-1">
                            {hotspot.time}
                          </div>
                          <div className="text-sm text-orange-700">
                            <span className="font-medium">{hotspot.percentage}%</span> of class showed confusion signals
                          </div>
                          <div className="text-xs text-orange-600 mt-1">
                            {hotspot.studentCount} students affected
                          </div>
                        </div>
                        <div className="bg-orange-200 text-orange-800 px-3 py-1 rounded-full text-xs font-bold">
                          CONFUSION
                        </div>
                      </div>
                    </div>
                  ))}
                  <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm text-blue-800">
                      <strong>Tip:</strong> Review these time periods in your recording to identify difficult concepts
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div> */}

          {/* AT RISK STUDENTS */}
          {/* <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">
              Students At Risk
            </h3>
            <div className="bg-gray-50 rounded-lg p-4 border">
              {atRiskStudents.length === 0 ? (
                <div className="text-center py-8">
                  <div className="text-5xl mb-2"></div>
                  <p className="text-gray-600 font-medium">All students maintained good engagement!</p>
                  <p className="text-sm text-gray-500 mt-1">No at-risk students identified</p>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="text-sm text-gray-600 mb-3">
                    These students showed consistently low engagement (&lt;35%) and may need additional support
                  </div>
                  {atRiskStudents.map((student, idx) => (
                    <div key={idx} className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-red-900">
                          {student.userId}
                        </div>
                        <div className="text-sm text-red-700 mt-1">
                          Avg Engagement: <span className="font-bold">{(student.avgScore * 100).toFixed(0)}%</span>
                        </div>
                        {student.strikes > 0 && (
                          <div className="text-xs text-red-600 mt-1">
                            Strike count: {student.strikes}
                          </div>
                        )}
                      </div>
                      <div className="bg-red-200 text-red-800 px-3 py-1 rounded-full text-xs font-bold">
                        HIGH RISK
                      </div>
                    </div>
                  ))}
                  <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm text-blue-800">
                      <strong>Recommendation:</strong> Follow up with these students individually to provide support
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div> */}
        </div>

        {/* Actions */}
        <div className="p-6 border-t bg-gray-50 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-lg font-medium text-gray-700 hover:bg-gray-200 transition"
          >
            Close
          </button>
          <button
            onClick={onSave}
            className="px-6 py-2 rounded-lg font-medium bg-blue-600 text-white hover:bg-blue-700 transition shadow-md"
          >
            Save Report
          </button>
        </div>

      </div>
    </div>
  );
}