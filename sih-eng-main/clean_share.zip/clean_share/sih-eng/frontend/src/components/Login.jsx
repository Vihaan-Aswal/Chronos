// src/components/Login.jsx

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../supabaseClient";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  async function handleSignup() {
    const { error: loginError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (!loginError) {
      alert("User already registered. Please log in.");
      return;
    }

    if (loginError.message !== "Invalid login credentials") {
      alert("Signup error: " + loginError.message);
      return;
    }

    const { error: signupError } =
      await supabase.auth.signUp({ email, password });

    if (signupError) {
      alert("Signup failed: " + signupError.message);
      return;
    }

    alert("Signup successful! Please log in now.");
  }

  async function loginAndRedirect(role) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) return alert("Login failed: " + error.message);

    // Map to internal roles
    const internalRole = role === "host" ? "teacher" : "student";

    navigate(`/${internalRole}`, {
      state: { user: data.user, role: internalRole },
    });
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-slate-800 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-md border border-white/20 shadow-xl rounded-2xl p-8 w-full max-w-sm">
        
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🎓</div>
          <h2 className="text-white text-3xl font-bold mb-2">
            Smart Classroom
          </h2>
        </div>

        <input
          type="email"
          placeholder="Email"
          className="w-full p-3 rounded-md bg-white/20 text-white placeholder-gray-300 mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          className="w-full p-3 rounded-md bg-white/20 text-white placeholder-gray-300 mb-6 focus:outline-none focus:ring-2 focus:ring-blue-400"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          onClick={handleSignup}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-md transition mb-6 shadow-lg"
        >
          Sign Up
        </button>

        <div className="text-center text-gray-300 mb-4 text-sm">
          Choose your role
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => loginAndRedirect("host")}
            className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2.5 rounded-md transition shadow-lg"
          >
            Host
          </button>

          <button
            onClick={() => loginAndRedirect("join")}
            className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-2.5 rounded-md transition shadow-lg"
          >
            Join
          </button>
        </div>
      </div>
    </div>
  );
}