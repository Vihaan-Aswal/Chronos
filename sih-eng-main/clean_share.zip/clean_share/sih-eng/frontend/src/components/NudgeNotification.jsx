import { createPortal } from "react-dom";

function NudgeNotification({ message }) {
  if (!message) return null;

  return createPortal(
    <div 
      className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-yellow-500 text-white px-6 py-3 rounded-xl shadow-2xl z-[99999] pointer-events-none animate-fade-in-out"
      style={{ 
        position: "fixed",
        zIndex: 99999,
        pointerEvents: "none"
      }}
    >
      <div className="flex items-center gap-2">
        <span className="text-xl">🔔</span>
        <span className="font-semibold">{message}</span>
      </div>
    </div>,
    document.body
  );
}

export default NudgeNotification;








