import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';

import App from './App.jsx';
import StudentPage from './pages/StudentPage.jsx';
import TeacherPage from './pages/TeacherPage.jsx';
import VideoClassroom from './100ms/VideoClassroom.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>

      {/* Simple navigation for development */}
      <nav style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>
        <Link to="/" style={{ marginRight: '10px' }}>Home</Link>
        <Link to="/student" style={{ marginRight: '10px' }}>Student</Link>
        <Link to="/teacher" style={{ marginRight: '10px' }}>Teacher</Link>
      </nav>

      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/student" element={<StudentPage />} />
        <Route path="/teacher" element={<TeacherPage />} />

        {/* NEW 100ms Video Classroom */}
        <Route path="/classroom" element={<VideoClassroom />} />
      </Routes>

    </BrowserRouter>
  </React.StrictMode>,
);
