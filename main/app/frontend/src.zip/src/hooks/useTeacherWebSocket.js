import { useEffect, useRef, useState } from "react";

/**
 * Custom hook for teacher WebSocket connection to receive student engagement data
 * @param {string} sessionId - Session ID to subscribe to
 * @returns {{ connected: boolean, students: object }}
 */
function useTeacherWebSocket(sessionId) {
  const [connected, setConnected] = useState(false);
  const [students, setStudents] = useState({});
  const wsRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);
  const reconnectAttemptRef = useRef(0);

  useEffect(() => {
    if (!sessionId) return;

    let isMounted = true;

    function connect() {
      if (!isMounted) return;

      const wsUrl = `${import.meta.env.VITE_BACKEND_WS_URL || "ws://localhost:8000"}/ws/teacher/${sessionId}`;

      try {
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          if (!isMounted) return;
          setConnected(true);
          reconnectAttemptRef.current = 0;
        };

        ws.onmessage = (event) => {
          if (!isMounted) return;
          try {
            const message = JSON.parse(event.data);
            
            // Update student data
            if (message.user_id) {
              setStudents((prev) => ({
                ...prev,
                [message.user_id]: {
                  score: message.score,
                  timestamp: message.timestamp,
                  gaze_direction: message.gaze_direction,
                  ear: message.ear,
                  head_pose: message.head_pose,
                  presence: message.presence,
                  session_id: message.session_id,
                },
              }));
            }
          } catch (error) {
            console.error("Error parsing teacher WebSocket message:", error);
          }
        };

        ws.onclose = () => {
          if (!isMounted) return;
          setConnected(false);
          wsRef.current = null;

          // Auto-reconnect after 3 seconds
          reconnectTimeoutRef.current = setTimeout(() => {
            if (isMounted) {
              reconnectAttemptRef.current++;
              connect();
            }
          }, 3000);
        };

        ws.onerror = (error) => {
          console.error("Teacher WebSocket error:", error);
          if (!isMounted) return;
          setConnected(false);
        };
      } catch (error) {
        console.error("Teacher WebSocket connection error:", error);
        if (!isMounted) return;
        setConnected(false);

        // Retry connection after 3 seconds
        reconnectTimeoutRef.current = setTimeout(() => {
          if (isMounted) {
            reconnectAttemptRef.current++;
            connect();
          }
        }, 3000);
      }
    }

    // Initial connection
    connect();

    // Cleanup on unmount
    return () => {
      isMounted = false;
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [sessionId]);

  return { connected, students };
}

export default useTeacherWebSocket;






