import { useEffect, useRef, useState } from "react";

/**
 * Custom hook for WebSocket connections with auto-reconnect
 * @param {string} url - WebSocket URL
 * @param {function} onMessage - Optional callback for incoming messages
 * @returns {{ connected: boolean, send: (data: object) => void }}
 */
function useWebSocket(url, onMessage = null) {
  const [connected, setConnected] = useState(false);
  const wsRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);
  const reconnectAttemptRef = useRef(0);
  const onMessageRef = useRef(onMessage);

  // Update onMessage ref when it changes
  useEffect(() => {
    onMessageRef.current = onMessage;
  }, [onMessage]);

  useEffect(() => {
    if (!url || url === "") {
      console.warn("[useWebSocket] No URL provided, skipping connection");
      return;
    }

    let isMounted = true;

    function connect() {
      if (!isMounted) return;

      console.log("[useWebSocket] Connecting to:", url);
      try {
        const ws = new WebSocket(url);
        wsRef.current = ws;

        ws.onopen = () => {
          if (!isMounted) return;
          console.log("[useWebSocket] Connected successfully");
          setConnected(true);
          reconnectAttemptRef.current = 0;
        };

        ws.onmessage = (event) => {
          if (!isMounted) return;
          try {
            const message = JSON.parse(event.data);
            console.log("[WebSocket] Received message:", message);
            if (onMessageRef.current) {
              onMessageRef.current(message);
            } else {
              console.warn("[WebSocket] No onMessage handler registered");
            }
          } catch (error) {
            console.error("Error parsing WebSocket message:", error);
          }
        };

        ws.onclose = () => {
          if (!isMounted) return;
          setConnected(false);
          wsRef.current = null;

          // Auto-reconnect after 3 seconds
          reconnectTimeoutRef.current = setTimeout(() => {
            if (isMounted) {
              reconnectAttemptRef.current++;
              connect();
            }
          }, 3000);
        };

        ws.onerror = (error) => {
          console.error("WebSocket error:", error);
          if (!isMounted) return;
          setConnected(false);
        };
      } catch (error) {
        console.error("WebSocket connection error:", error);
        if (!isMounted) return;
        setConnected(false);

        // Retry connection after 3 seconds
        reconnectTimeoutRef.current = setTimeout(() => {
          if (isMounted) {
            reconnectAttemptRef.current++;
            connect();
          }
        }, 3000);
      }
    }

    // Initial connection
    connect();

    // Cleanup on unmount
    return () => {
      isMounted = false;
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [url]);

  const send = (data) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      try {
        wsRef.current.send(JSON.stringify(data));
      } catch (error) {
        console.error("Error sending WebSocket message:", error);
      }
    }
  };

  return { connected, send };
}

export default useWebSocket;

