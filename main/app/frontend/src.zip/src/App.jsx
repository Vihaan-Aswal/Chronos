// src/App.jsx
import { useState, useEffect } from "react";
import { supabase } from "./supabaseClient";

import Login from "./components/Login";
import StudentPage from "./pages/StudentPage";
import VideoClassroom from "./100ms/VideoClassroom";

function App() {
  const [user, setUser] = useState(null);

  // Check session on refresh
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data.user);
    });
  }, []);

  // Not logged in → show login page
  if (!user) return <Login onLogin={setUser} />;

  // Logged in → show student dashboard
  return <StudentPage user={user} />;
}

export default App;
