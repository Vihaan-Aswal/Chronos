// src/api/identity.js

const BASE = "http://localhost:8000";

export async function registerIdentity(userId, embedding) {
  const res = await fetch(`${BASE}/identity/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user_id: userId,
      embedding: Array.from(embedding),
    }),
  });

  return res.json();
}

export async function fetchIdentity(userId) {
  const res = await fetch(`${BASE}/identity/${userId}`);
  return res.json();
}
