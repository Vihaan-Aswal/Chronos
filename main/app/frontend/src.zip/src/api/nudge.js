const BASE = import.meta.env.VITE_BACKEND_URL || "http://localhost:8000";

/**
 * Send a nudge to a student
 * @param {string} sessionId - Session ID
 * @param {string} userId - User ID of the student
 * @param {string} type - Nudge type: "soft" or "hard"
 * @returns {Promise<object>} Response from server
 */
export async function sendNudge(sessionId, userId, type) {
  const response = await fetch(`${BASE}/nudge/send`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      session_id: sessionId,
      user_id: userId,
      nudge_type: type,
    }),
  });

  if (!response.ok) {
    throw new Error(`Failed to send nudge: ${response.statusText}`);
  }

  return response.json();
}






