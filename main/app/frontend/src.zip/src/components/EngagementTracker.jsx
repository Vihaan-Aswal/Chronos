import { useEffect, useRef } from "react";
import useWebSocket from "../hooks/useWebSocket";

function EngagementTracker({ sessionId, userId, onNudge }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  // ---------- HELPERS ----------
  const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

  function computeEAR(landmarks, [upper, lower, inner, outer]) {
    if (!landmarks || landmarks.length === 0) return 0;
    if (!landmarks[upper] || !landmarks[lower] || !landmarks[inner] || !landmarks[outer]) return 0;
    const vertical = distance(landmarks[upper], landmarks[lower]);
    const horizontal = distance(landmarks[inner], landmarks[outer]);
    return horizontal > 0 ? vertical / horizontal : 0;
  }

  // ---------- GAZE CALIB ----------
  const gazeCalib = useRef({
    samples: [],
    centerAvg: 0.5,
    calibrated: false,
    smoothHoriz: 0.5,
    smoothVert: 0.3,
  }).current;

  // ---------- POSE / PRESENCE / ENGAGEMENT ----------
  const poseState = useRef({
    smoothYaw: 0,
    smoothPitch: 0,
    turned: false,
    lookingDown: false,
  }).current;

  const presenceState = useRef({ status: "unknown", bboxArea: 0 }).current;
  const engagementState = useRef({ score: 1, smoothScore: 1 }).current;
  
  // Store current engagement metrics for WebSocket sending
  const currentMetricsRef = useRef({
    gazeDirection: "center",
    ear: 0,
    headPose: { yaw: 0, pitch: 0 },
    presence: "unknown",
  });

  // ---------- GAZE ----------
  function gazeDirection(lm) {
    const LEFT_IRIS = 473, RIGHT_IRIS = 468;
    const LEFT_INNER = 263, LEFT_OUTER = 362;
    const RIGHT_INNER = 133, RIGHT_OUTER = 33;
    const [L_UP, L_DOWN] = [386, 374];
    const [R_UP, R_DOWN] = [159, 145];

    const horiz = ((lm[LEFT_IRIS].x - lm[LEFT_INNER].x) /
                  (lm[LEFT_OUTER].x - lm[LEFT_INNER].x) +
                  (lm[RIGHT_IRIS].x - lm[RIGHT_INNER].x) /
                  (lm[RIGHT_OUTER].x - lm[RIGHT_INNER].x)) / 2;

    const down = ((lm[LEFT_IRIS].y - lm[L_UP].y) /
                 (lm[L_DOWN].y - lm[L_UP].y) +
                 (lm[RIGHT_IRIS].y - lm[R_UP].y) /
                 (lm[R_DOWN].y - lm[R_UP].y)) / 2;

    gazeCalib.smoothHoriz = horiz;
    gazeCalib.smoothVert = down;

    if (!gazeCalib.calibrated) {
      gazeCalib.samples.push(horiz);
      if (gazeCalib.samples.length >= 25) {
        gazeCalib.centerAvg = 0.5;
        gazeCalib.calibrated = true;
      }
    }

    const c = gazeCalib.centerAvg;
    let dir = "center";
    if (down > 0.75) dir = "down";
    else if (horiz < c - 0.07) dir = "left";
    else if (horiz > c + 0.07) dir = "right";

    return { horizontal: horiz, vertical: down, direction: dir };
  }

  // ---------- HEAD POSE ----------
  function estimateHeadPose(lm) {
    const nose = lm[1] ?? lm[4];
    const leftIris = lm[473];
    const rightIris = lm[468];
    const eyeMid = { x: (leftIris.x + rightIris.x)/2, y: (leftIris.y + rightIris.y)/2 };

    let minX=1, minY=1, maxX=0, maxY=0;
    for (let p of lm) {
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x);
      maxY = Math.max(maxY, p.y);
    }

    const faceW = maxX - minX || 1e-6;
    const faceH = maxY - minY || 1e-6;

    const yaw = (nose.x - (minX+maxX)/2) / faceW;
    const pitch = (nose.y - eyeMid.y) / faceH;

    poseState.smoothYaw = poseState.smoothYaw * 0.75 + yaw * 0.25;
    poseState.smoothPitch = poseState.smoothPitch * 0.75 + pitch * 0.25;

    poseState.turned = Math.abs(poseState.smoothYaw) > 0.08;
    poseState.lookingDown = poseState.smoothPitch > 0.06;

    return {
      yaw: poseState.smoothYaw,
      pitch: poseState.smoothPitch,
      turned: poseState.turned,
      lookingDown: poseState.lookingDown,
    };
  }

  // ---------- PRESENCE ----------
  function checkPresence(lm) {
    if (!lm) {
      presenceState.status = "no_face";
      return presenceState;
    }
    let minX = 1, minY = 1, maxX = 0, maxY = 0;
    for (let p of lm) {
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x);
      maxY = Math.max(maxY, p.y);
    }

    const area = (maxX - minX) * (maxY - minY);
    presenceState.status = area > 0.0001 ? "present" : "no_face";
    return presenceState;
  }

  // ---------- SCORE HELPERS ----------
  const scoreFromGaze = g => g.direction === "center" ? 1 : 0;
  const scoreFromHeadPose = p =>
    (!p.turned && !p.lookingDown) ? 1 :
    (p.turned && Math.abs(p.yaw) < 0.12) ? 0.6 : 0;
  const scoreFromPresence = p => p.status === "present" ? 1 : 0;
  const scoreFromEye = s =>
    s === "eyes_open" ? 1 :
    s === "blink" ? 0.9 :
    s === "closed_brief" ? 0.6 :
    s === "microsleep" ? 0.2 :
    0;

  // ---------- BLINK STATE ----------
  const blinkData = useRef({
    lastEAR: 0,
    smoothEAR: 0,
    blinkStart: null,
    closedStart: null,
    status: "eyes_open",
  }).current;

  // ---------- EAR INDICES (YOUR ORIGINAL CORRECT ONES) ----------
  const leftEyeIdx = [386, 374, 263, 362];
  const rightEyeIdx = [159, 145, 133, 33];

  // ------------------ FIXED EAR THRESHOLDS ------------------
  const OPEN_THRESHOLD = 0.32;
  const BLINK_THRESHOLD = 0.26;
  const CLOSED_THRESHOLD = 0.22;

  // ---------- WEBSOCKET SETUP ----------
  const wsUrl = sessionId && userId
    ? `${import.meta.env.VITE_BACKEND_WS_URL || "ws://localhost:8000"}/ws/engagement/${sessionId}/${userId}`
    : null;
  
  // Handle incoming messages (nudges)
  const handleMessage = (message) => {
    console.log("[EngagementTracker] Received WebSocket message:", message);
    if (message.type === "nudge") {
      console.log("[EngagementTracker] Nudge received, calling onNudge");
      console.log("[EngagementTracker] onNudge prop:", typeof onNudge, onNudge ? "exists" : "missing");
      if (onNudge) {
        console.log("[EngagementTracker] Calling onNudge with:", message);
        onNudge(message);
      } else {
        console.warn("[EngagementTracker] onNudge callback not provided");
      }
    }
  };
  
  const { connected, send } = useWebSocket(wsUrl || "", handleMessage);

  // ---------- WEBSOCKET SEND INTERVAL ----------
  useEffect(() => {
    if (!sessionId || !userId || !wsUrl) return;

    const interval = setInterval(() => {
      if (connected && engagementState && engagementState.smoothScore !== undefined) {
        const metrics = currentMetricsRef.current;
        send({
          session_id: sessionId,
          user_id: userId,
          score: engagementState.smoothScore,
          timestamp: new Date().toISOString(),
          gaze_direction: metrics?.gazeDirection || "center",
          ear: metrics?.ear || 0,
          head_pose: metrics?.headPose || { yaw: 0, pitch: 0 },
          presence: metrics?.presence || "unknown",
        });
      }
    }, 3000); // Send every 3 seconds

    return () => clearInterval(interval);
  }, [connected, send, sessionId, userId, wsUrl]);

  // ---------- MAIN EFFECT ----------
  useEffect(() => {
    let stream = null;
    let loop = null;
    let faceLandmarker;
    let isMounted = true;

    async function init() {
      if (!isMounted) return;
      const vision = await import("@mediapipe/tasks-vision");
      const filesetResolver = await vision.FilesetResolver.forVisionTasks(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.4/wasm"
      );

      faceLandmarker = await vision.FaceLandmarker.createFromOptions(
        filesetResolver,
        {
          baseOptions: {
            modelAssetPath:
              "https://storage.googleapis.com/mediapipe-assets/face_landmarker_v2.task",
          },
          runningMode: "video",
          numFaces: 1,
        }
      );

      stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 720, height: 540 },
        audio: false,
      });

      videoRef.current.srcObject = stream;
      await videoRef.current.play();
      detect();
    }

    function detect() {
      if (!isMounted || !videoRef.current || !canvasRef.current) return;

      const results = faceLandmarker.detectForVideo(
        videoRef.current,
        performance.now()
      );

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (!results || !results.faceLandmarks) {
        presenceState.status = "no_face";
        if (isMounted) loop = requestAnimationFrame(detect);
        return;
      }

      const lm = results.faceLandmarks[0];
      if (!lm || lm.length === 0) {
        presenceState.status = "no_face";
        if (isMounted) loop = requestAnimationFrame(detect);
        return;
      }

      const pres = checkPresence(lm);

      // ---------- EAR ----------
      const leftEAR = computeEAR(lm, leftEyeIdx);
      const rightEAR = computeEAR(lm, rightEyeIdx);
      const EAR = (leftEAR + rightEAR) / 2;

      // ---------- FAST SMOOTHING ----------
      blinkData.smoothEAR = EAR * 0.8 + blinkData.smoothEAR * 0.2;
      const smooth = blinkData.smoothEAR;
      const now = performance.now();

      // ---------- STATE LOGIC ----------
      if (smooth > OPEN_THRESHOLD) {
        blinkData.status = "eyes_open";
        blinkData.blinkStart = null;
        blinkData.closedStart = null;
        blinkData.smoothEAR = smooth; // hard reset
      }
      else if (smooth < BLINK_THRESHOLD && smooth > CLOSED_THRESHOLD) {
        if (!blinkData.blinkStart) blinkData.blinkStart = now;
        if (now - blinkData.blinkStart < 250) blinkData.status = "blink";
      }
      else if (smooth <= CLOSED_THRESHOLD) {
        if (!blinkData.closedStart) blinkData.closedStart = now;
        const duration = now - blinkData.closedStart;

        if (duration > 1000) blinkData.status = "closed_long";
        else if (duration > 400) blinkData.status = "microsleep";
        else blinkData.status = "closed_brief";
      }

      // ---------- Draw debug ----------
      const draw = (i, c) => {
        const p = lm[i];
        ctx.fillStyle = c;
        ctx.beginPath();
        ctx.arc(p.x * canvas.width, p.y * canvas.height, 4, 0, Math.PI * 2);
        ctx.fill();
      };

      draw(386,"cyan"); draw(374,"cyan");
      draw(359,"lime"); draw(384,"lime");

      draw(159,"cyan"); draw(145,"cyan");
      draw(133,"lime"); draw(130,"lime");

      // ---------- Gaze + Pose ----------
      let gaze, pose;
      try {
        gaze = gazeDirection(lm);
        pose = estimateHeadPose(lm);
      } catch (error) {
        console.error("Error computing gaze/pose:", error);
        presenceState.status = "no_face";
        if (isMounted) loop = requestAnimationFrame(detect);
        return;
      }

      // ---------- Engagement ----------
      const raw =
        scoreFromPresence(pres) * 0.3 +
        scoreFromGaze(gaze) * 0.25 +
        scoreFromHeadPose(pose) * 0.2 +
        scoreFromEye(blinkData.status) * 0.25;

      if (engagementState && engagementState.smoothScore !== undefined) {
        engagementState.smoothScore =
          engagementState.smoothScore * 0.85 + raw * 0.15;
      } else {
        engagementState.smoothScore = raw;
      }

      // ---------- Update metrics for WebSocket ----------
      if (gaze && pose && pres) {
        currentMetricsRef.current = {
          gazeDirection: gaze.direction || "center",
          ear: smooth || 0,
          headPose: { yaw: pose.yaw || 0, pitch: pose.pitch || 0 },
          presence: pres.status || "unknown",
        };
      }

      // ---------- HUD ----------
      ctx.fillStyle = "rgba(0,0,0,0.45)";
      ctx.fillRect(6, 6, 260, 100);

      ctx.fillStyle = "white";
      ctx.font = "12px monospace";
      ctx.fillText(`Presence: ${pres.status}`, 12, 26);
      ctx.fillText(
        `Gaze: ${gaze.direction} H:${gaze.horizontal.toFixed(2)} V:${gaze.vertical.toFixed(2)}`,
        12, 44
      );
      ctx.fillText(
        `Head yaw:${pose.yaw.toFixed(3)} pitch:${pose.pitch.toFixed(3)}`, 12, 62
      );
      ctx.fillText(
        `Eye: ${blinkData.status} EAR:${smooth.toFixed(3)}`, 12, 80
      );
      ctx.fillText(
        `L:${leftEAR.toFixed(3)} R:${rightEAR.toFixed(3)}
Score:${Math.round(engagementState.smoothScore * 100)}%`,
        12, 98
      );

      if (isMounted) loop = requestAnimationFrame(detect);
    }

    init();

    return () => {
      isMounted = false;
      cancelAnimationFrame(loop);
      if (stream) stream.getTracks().forEach(t => t.stop());
    };
  }, []);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold text-gray-900">Engagement Tracker</h3>
        {/* WebSocket Connection Status Indicator */}
        {wsUrl && (
          <div className="px-2 py-1 rounded text-xs font-medium">
            {connected ? (
              <span className="text-green-600 bg-green-100 px-2 py-0.5 rounded">🟢 Connected</span>
            ) : (
              <span className="text-red-600 bg-red-100 px-2 py-0.5 rounded">🔴 Disconnected</span>
            )}
          </div>
        )}
      </div>
      <div className="relative w-full bg-black rounded-lg overflow-hidden" style={{ aspectRatio: "4/3" }}>
        <video ref={videoRef} style={{ display: "none" }} />
        <canvas
          ref={canvasRef}
          width={720}
          height={540}
          className="w-full h-full object-contain"
          style={{ position: "absolute", top: 0, left: 0 }}
        />
      </div>
    </div>
  );
}

export default EngagementTracker;
