// src/components/JoinScreen.jsx

import { useEffect, useRef, useState } from "react";
import { loadEmbedder, getEmbedding } from "../utils/embedder";
import { fetchIdentity, registerIdentity } from "../api/identity";

function JoinScreen({ user, onJoin }) {
  const videoRef = useRef(null);
  const cropCanvasRef = useRef(null);
  const lightCanvasRef = useRef(null);

  const [facePresent, setFacePresent] = useState(false);
  const [isCentered, setIsCentered] = useState(false);
  const [lightStatus, setLightStatus] = useState("unknown");
  const [ready, setReady] = useState(false);

  const userId = user.id; // Supabase UUID ✔

  useEffect(() => {
    let stream;
    let faceLandmarker;
    let animationFrameId;

    loadEmbedder(); // Load face-api.js ONCE

    async function init() {
      // Start webcam
      stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoRef.current.srcObject = stream;
      await videoRef.current.play();

      // Load MediaPipe model
      const vision = await import("@mediapipe/tasks-vision");
      const FilesetResolver = vision.FilesetResolver;
      const FaceLandmarker = vision.FaceLandmarker;

      const fileset = await FilesetResolver.forVisionTasks(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.4/wasm"
      );

      faceLandmarker = await FaceLandmarker.createFromOptions(fileset, {
        baseOptions: {
          modelAssetPath:
            "https://storage.googleapis.com/mediapipe-assets/face_landmarker_v2.task",
        },
        runningMode: "VIDEO",
        numFaces: 1,
      });

      detect();
    }

    function detect() {
      const video = videoRef.current;
      if (!video) return;

      // ---- LIGHT CHECK ----
      const L = lightCanvasRef.current.getContext("2d");
      L.drawImage(video, 0, 0, 300, 220);
      const frame = L.getImageData(0, 0, 300, 220);

      let total = 0;
      for (let i = 0; i < frame.data.length; i += 4) {
        total += (frame.data[i] + frame.data[i + 1] + frame.data[i + 2]) / 3;
      }

      const brightness = total / (frame.data.length / 4);
      let light = "good";
      if (brightness < 60) light = "too_dark";
      if (brightness > 180) light = "too_bright";
      setLightStatus(light);

      // ---- FACE LANDMARKS ----
      const result = faceLandmarker.detectForVideo(video, performance.now());
      const faces = result.faceLandmarks;
      const hasFace = faces && faces.length > 0;

      setFacePresent(hasFace);

      if (!hasFace) {
        setIsCentered(false);
        setReady(false);
        animationFrameId = requestAnimationFrame(detect);
        return;
      }

      const lm = faces[0];

      let minX = 1, maxX = 0, minY = 1, maxY = 0;
      lm.forEach((p) => {
        if (p.x < minX) minX = p.x;
        if (p.x > maxX) maxX = p.x;
        if (p.y < minY) minY = p.y;
        if (p.y > maxY) maxY = p.y;
      });

      const centered =
        Math.abs((minX + maxX) / 2 - 0.5) < 0.15 &&
        Math.abs((minY + maxY) / 2 - 0.5) < 0.15;

      setIsCentered(centered);

      const ok = hasFace && centered && light === "good";
      setReady(ok);

      // ---- CROP FACE ----
      const C = cropCanvasRef.current.getContext("2d");
      C.drawImage(
        video,
        minX * video.videoWidth,
        minY * video.videoHeight,
        (maxX - minX) * video.videoWidth,
        (maxY - minY) * video.videoHeight,
        0, 0, 112, 112
      );

      animationFrameId = requestAnimationFrame(detect);
    }

    init();

    return () => {
      if (stream) stream.getTracks().forEach((t) => t.stop());
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  // ================================
  //  FACE VERIFICATION (FIXED) 🔥
  // ================================

  // Normalize 128-D embedding to unit length
  function normalize(vec) {
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    return vec.map((v) => v / norm);
  }

  // L2 distance (BEST for face-api.js)
  function l2Distance(a, b) {
    let sum = 0;
    for (let i = 0; i < a.length; i++) {
      const diff = a[i] - b[i];
      sum += diff * diff;
    }
    return Math.sqrt(sum);
  }

  async function handleJoin() {
    const canvas = cropCanvasRef.current;
    let emb = await getEmbedding(canvas);

    if (!emb) return alert("Face not detected properly.");

    emb = normalize(Array.from(emb)); // IMPORTANT

    const info = await fetchIdentity(userId);

    // First-time user → register
    if (!info.exists) {
      await registerIdentity(userId, emb);
      alert("Face registered! You may join now.");
      return onJoin?.();
    }

    // Compare with stored embedding
    const stored = normalize(info.embedding);

    const dist = l2Distance(emb, stored);
    console.log("L2 distance:", dist);

    const threshold = 0.47;

    if (dist < threshold) {
      alert("Identity verified!");
      onJoin?.();
    } else {
      alert("Face mismatch! Access denied.");
    }

    navigate(`/classroom?roomCode=${roomCode}&user=${userName}`);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-8 max-w-md w-full">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Identity Verification</h2>
          <p className="text-sm text-gray-600">Position your face in the center and ensure good lighting</p>
        </div>

        <div className="relative mb-6">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full rounded-lg bg-black"
            style={{ aspectRatio: "4/3" }}
          />
          <canvas ref={lightCanvasRef} width={300} height={220} style={{ display: "none" }} />
          <canvas ref={cropCanvasRef} width={112} height={112} style={{ display: "none" }} />
        </div>

        <div className="space-y-3 mb-6">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <span className="text-sm font-medium text-gray-700">Face Detected</span>
            <span className={`text-sm font-semibold ${facePresent ? "text-green-600" : "text-red-600"}`}>
              {facePresent ? "✔️ Yes" : "❌ No"}
            </span>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <span className="text-sm font-medium text-gray-700">Face Centered</span>
            <span className={`text-sm font-semibold ${isCentered ? "text-green-600" : "text-red-600"}`}>
              {isCentered ? "✔️ Yes" : "❌ No"}
            </span>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <span className="text-sm font-medium text-gray-700">Lighting</span>
            <span className={`text-sm font-semibold ${
              lightStatus === "good" ? "text-green-600" :
              lightStatus === "too_dark" ? "text-yellow-600" :
              "text-red-600"
            }`}>
              {lightStatus === "good" ? "✔️ Good" :
               lightStatus === "too_dark" ? "⚠️ Too Dark" :
               "⚠️ Too Bright"}
            </span>
          </div>
        </div>

        <button
          disabled={!ready}
          onClick={handleJoin}
          className={`w-full py-3 px-6 rounded-lg font-semibold text-white transition-all duration-200 ${
            ready
              ? "bg-blue-600 hover:bg-blue-700 shadow-lg hover:shadow-xl transform hover:scale-[1.02]"
              : "bg-gray-400 cursor-not-allowed"
          }`}
        >
          {ready ? "Verify & Join Meeting" : "Please adjust your position"}
        </button>
      </div>
    </div>
  );
}

export default JoinScreen;
