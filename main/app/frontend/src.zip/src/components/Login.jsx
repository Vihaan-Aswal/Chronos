import { useState } from "react";
import { supabase } from "../supabaseClient";

function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function handleLogin() {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) return alert("Login failed: " + error.message);

    onLogin(data.user);
  }

  async function handleSignup() {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) return alert("Signup failed: " + error.message);

    alert("Signup success! Now log in.");
  }

  return (
    <div style={{ padding: 20, textAlign: "center" }}>
      <h2>Login / Signup</h2>

      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        style={{ margin: 10, padding: 8 }}
      />

      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        style={{ margin: 10, padding: 8 }}
      />

      <br />

      <button onClick={handleLogin} style={{ margin: 10 }}>
        Log In
      </button>

      <button onClick={handleSignup} style={{ margin: 10 }}>
        Sign Up
      </button>
    </div>
  );
}

export default Login;
