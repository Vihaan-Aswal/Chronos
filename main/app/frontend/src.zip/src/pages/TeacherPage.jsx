import { useSearchParams } from "react-router-dom";
import useTeacherWebSocket from "../hooks/useTeacherWebSocket";
import NudgeButton from "../components/NudgeButton";

function TeacherPage() {
  const [searchParams] = useSearchParams();
  // Get sessionId from query params or use placeholder
  const sessionId = searchParams.get("sessionId") || "default-session";
  
  const { connected, students } = useTeacherWebSocket(sessionId);

  // Convert students object to array for rendering
  const studentsArray = Object.entries(students).map(([userId, data]) => ({
    userId,
    ...data,
  }));

  const getStatusLabel = (score) => {
    if (score > 0.7) return "Attentive";
    if (score >= 0.4) return "Distracted";
    return "Away";
  };

  const getStatusColor = (score) => {
    if (score > 0.7) return "text-green-600";
    if (score >= 0.4) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header with connection status */}
      <div className="bg-white shadow-md border-b border-gray-200 px-6 py-5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Teacher Dashboard</h1>
            <p className="text-sm text-gray-600 mt-1">Session: <span className="font-mono font-semibold">{sessionId}</span></p>
          </div>
          <div className="flex items-center gap-4">
            <div className="px-4 py-2 rounded-lg text-sm font-medium shadow-sm border border-gray-200">
              {connected ? (
                <span className="text-green-700 bg-green-50 px-3 py-1 rounded-md inline-flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                  Connected
                </span>
              ) : (
                <span className="text-red-700 bg-red-50 px-3 py-1 rounded-md inline-flex items-center gap-2">
                  <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                  Disconnected
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Student grid */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-800">
            Students ({studentsArray.length})
          </h2>
          <p className="text-sm text-gray-600 mt-1">Monitor engagement and send nudges</p>
        </div>

        {studentsArray.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <div className="max-w-md mx-auto">
              <div className="text-6xl mb-4">👥</div>
              <p className="text-lg font-medium text-gray-700 mb-2">No students connected yet</p>
              <p className="text-sm text-gray-500">Waiting for students to join the session...</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {studentsArray.map((student) => (
              <div
                key={student.userId}
                className="bg-white shadow-lg rounded-xl p-5 border border-gray-200 hover:shadow-xl transition-shadow duration-200 flex flex-col space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate" title={student.userId}>
                      Student {student.userId.substring(0, 8)}...
                    </h3>
                  </div>
                  <NudgeButton userId={student.userId} sessionId={sessionId} />
                </div>
                
                <div className="space-y-2 pt-2 border-t border-gray-100">
                  <div className="flex items-baseline gap-2">
                    <span className={`text-3xl font-bold ${
                      student.score > 0.7 ? "text-green-600" :
                      student.score >= 0.4 ? "text-yellow-600" :
                      "text-red-600"
                    }`}>
                      {(student.score * 100).toFixed(0)}%
                    </span>
                    <span className="text-xs text-gray-500 font-medium">engagement</span>
                  </div>
                  
                  <div className={`text-sm font-semibold ${getStatusColor(student.score)} inline-block px-2 py-1 rounded-md bg-opacity-10 ${
                    student.score > 0.7 ? "bg-green-100" :
                    student.score >= 0.4 ? "bg-yellow-100" :
                    "bg-red-100"
                  }`}>
                    {getStatusLabel(student.score)}
                  </div>
                </div>

                {student.timestamp && (
                  <div className="text-xs text-gray-400 pt-2 border-t border-gray-100">
                    <span className="font-medium">Last update:</span> {new Date(student.timestamp).toLocaleTimeString()}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default TeacherPage;