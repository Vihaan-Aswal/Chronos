// src/pages/StudentPage.jsx
import { useState, useEffect, useRef } from "react";
import { useHMSActions, useHMSStore, selectPeers, selectIsLocalAudioEnabled, selectIsLocalVideoEnabled } from "@100mslive/react-sdk";

import JoinScreen from "../components/JoinScreen.jsx";
import EngagementTracker from "../components/EngagementTracker.jsx";
import NudgeNotification from "../components/NudgeNotification.jsx";

function StudentPage({ user }) {
  const peers = useHMSStore(selectPeers);
  const isAudioEnabled = useHMSStore(selectIsLocalAudioEnabled);
  const isVideoEnabled = useHMSStore(selectIsLocalVideoEnabled);
  const hmsActions = useHMSActions();

  const [showMeeting, setShowMeeting] = useState(false);
  const [nudgeNotification, setNudgeNotification] = useState(null);
  const [showEngagementPanel, setShowEngagementPanel] = useState(false);
  const nudgeTimeoutRef = useRef(null);

  const joinRoom = async () => {
    try {
      const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2ZXJzaW9uIjoyLCJ0eXBlIjoiYXBwIiwiYXBwX2RhdGEiOm51bGwsImFjY2Vzc19rZXkiOiI2OTMwNTk3M2JkMGRhYjVmOWEwMTRhOWMiLCJyb2xlIjoiaG9zdCIsInJvb21faWQiOiI2OTMwNTlkNGE1YmE4MzI2ZTZlYmQ3OTUiLCJ1c2VyX2lkIjoiMzViZDRhMzEtYTI2ZC00NTVlLWJiZGYtNGVkNTU1NDk0Nzg1IiwiZXhwIjoxNzY0OTYyMzY4LCJqdGkiOiJjMDkzMDg2ZS0wODdjLTRiMzYtYWRjNy01ODE5MGY1YTI4N2IiLCJpYXQiOjE3NjQ4NzU5NjgsImlzcyI6IjY5MzA1OTczYmQwZGFiNWY5YTAxNGE5YSIsIm5iZiI6MTc2NDg3NTk2OCwic3ViIjoiYXBpIn0.bul9qN_W6f5no_bPSX9zkQUPDSzHPGO_EcwAZmO_OkE";

      await hmsActions.join({
        userName: user.email,
        authToken: token,
      });

      setShowMeeting(true);
    } catch (err) {
      console.error("Join error:", err);
    }
  };

  // Handle nudge notifications - always sets a visible string
  const handleNudge = (nudgeMessage) => {
    console.log("StudentPage handleNudge triggered", nudgeMessage);
    
    // Clear any existing timeout
    if (nudgeTimeoutRef.current) {
      clearTimeout(nudgeTimeoutRef.current);
    }

    // Determine message based on nudge type
    const message = nudgeMessage?.nudge_type === "hard" 
      ? "Attention Required!" 
      : "Please pay attention";
    
    // Always set a visible string
    setNudgeNotification(message);
    console.log("StudentPage nudgeNotification set to:", message);
    
    // Auto-hide after 3 seconds
    nudgeTimeoutRef.current = setTimeout(() => {
      setNudgeNotification(null);
      nudgeTimeoutRef.current = null;
    }, 3000);
  };

  // Call controls
  const toggleMute = async () => {
    try {
      await hmsActions.setEnabledTrack(!isAudioEnabled, "audio");
    } catch (error) {
      console.error("Error toggling audio:", error);
    }
  };

  const toggleVideo = async () => {
    try {
      await hmsActions.setEnabledTrack(!isVideoEnabled, "video");
    } catch (error) {
      console.error("Error toggling video:", error);
    }
  };

  const leaveMeeting = async () => {
    try {
      await hmsActions.leave();
      setShowMeeting(false);
    } catch (error) {
      console.error("Error leaving meeting:", error);
    }
  };

  // Cleanup notification timeout on unmount
  useEffect(() => {
    return () => {
      if (nudgeTimeoutRef.current) {
        clearTimeout(nudgeTimeoutRef.current);
      }
      setNudgeNotification(null);
    };
  }, []);

  if (!showMeeting) {
    return <JoinScreen user={user} onJoin={joinRoom} />;
  }

  // Calculate grid layout based on number of peers
  const getGridCols = (count) => {
    if (count === 1) return "grid-cols-1";
    if (count === 2) return "grid-cols-2";
    if (count <= 4) return "grid-cols-2";
    if (count <= 9) return "grid-cols-3";
    return "grid-cols-4";
  };

  return (
    <>
      {/* Nudge Notification - Portal to document.body */}
      <NudgeNotification message={nudgeNotification} />

      {/* Google Meet-like Layout */}
      <div className="h-screen bg-[#202124] flex flex-col overflow-hidden">
        {/* Header Bar */}
        <div className="bg-[#1f1f1f] border-b border-[#3c4043] px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-white font-medium text-sm">Student Meeting</h1>
            <span className="text-[#9aa0a6] text-xs">Session: default-session</span>
          </div>
          <button
            onClick={() => setShowEngagementPanel(!showEngagementPanel)}
            className="text-white hover:bg-[#3c4043] px-3 py-1.5 rounded text-sm font-medium transition-colors"
          >
            {showEngagementPanel ? "Hide" : "Show"} Engagement
          </button>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex relative overflow-hidden">
          {/* Video Grid - Main Area */}
          <div className="flex-1 p-4 overflow-auto">
            {peers.length === 0 ? (
              <div className="h-full flex items-center justify-center">
                <div className="text-center text-[#9aa0a6]">
                  <p className="text-lg mb-2">Waiting for participants to join...</p>
                  <p className="text-sm">You'll see others here once they join</p>
                </div>
              </div>
            ) : (
              <div className={`grid ${getGridCols(peers.length)} gap-4 h-full`}>
                {peers.map((peer) => (
                  <div
                    key={peer.id}
                    className="relative bg-[#1f1f1f] rounded-lg overflow-hidden aspect-video group"
                  >
                    <video
                      autoPlay
                      playsInline
                      muted={peer.isLocal}
                      ref={(ref) => ref && hmsActions.attachVideo(peer.videoTrack, ref)}
                      className="w-full h-full object-cover"
                    />
                    {/* Name Badge */}
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3">
                      <div className="flex items-center gap-2">
                        {peer.isLocal && (
                          <span className="text-xs bg-[#ea4335] text-white px-2 py-0.5 rounded">You</span>
                        )}
                        <span className="text-white text-sm font-medium">{peer.name}</span>
                      </div>
                    </div>
                    {/* Audio indicator */}
                    {!peer.audioTrack && (
                      <div className="absolute top-3 right-3 bg-[#ea4335] rounded-full p-2">
                        <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.617.793L4.383 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.383l4-3.707zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.415z" clipRule="evenodd" />
                        </svg>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Floating Engagement Panel - Right Side */}
          {showEngagementPanel && (
            <div className="absolute right-4 top-4 bottom-20 w-80 bg-white rounded-lg shadow-2xl z-50 overflow-hidden">
              <div className="h-full overflow-y-auto p-4">
                <EngagementTracker 
                  sessionId="default-session" 
                  userId={user?.id} 
                  onNudge={handleNudge}
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer Bar with Controls */}
        <div className="bg-[#1f1f1f] border-t border-[#3c4043] px-4 py-3">
          <div className="flex items-center justify-center gap-2">
            {/* Mute Button */}
            <button
              onClick={toggleMute}
              className={`flex items-center justify-center w-10 h-10 rounded-full transition-colors ${
                isAudioEnabled
                  ? "bg-[#3c4043] hover:bg-[#5f6368] text-white"
                  : "bg-[#ea4335] hover:bg-[#d33b2c] text-white"
              }`}
              title={isAudioEnabled ? "Mute microphone" : "Unmute microphone"}
            >
              {isAudioEnabled ? (
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M13.477 14.89A6 6 0 015.11 6.524L8.09 9.504a2.5 2.5 0 003.848 3.848l2.98 2.98a.75.75 0 00.55-1.942zM5.11 6.524a6 6 0 008.364 8.364L5.11 6.524z" clipRule="evenodd" />
                  <path d="M4.343 3.293a1 1 0 011.414 0l10 10a1 1 0 11-1.414 1.414l-10-10a1 1 0 010-1.414z" />
                </svg>
              )}
            </button>

            {/* Camera Button */}
            <button
              onClick={toggleVideo}
              className={`flex items-center justify-center w-10 h-10 rounded-full transition-colors ${
                isVideoEnabled
                  ? "bg-[#3c4043] hover:bg-[#5f6368] text-white"
                  : "bg-[#ea4335] hover:bg-[#d33b2c] text-white"
              }`}
              title={isVideoEnabled ? "Turn off camera" : "Turn on camera"}
            >
              {isVideoEnabled ? (
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z" />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M13.477 14.89A6 6 0 015.11 6.524L8.09 9.504a2.5 2.5 0 003.848 3.848l2.98 2.98a.75.75 0 00.55-1.942zM5.11 6.524a6 6 0 008.364 8.364L5.11 6.524z" clipRule="evenodd" />
                  <path d="M4.343 3.293a1 1 0 011.414 0l10 10a1 1 0 11-1.414 1.414l-10-10a1 1 0 010-1.414z" />
                </svg>
              )}
            </button>

            {/* Leave Button */}
            <button
              onClick={leaveMeeting}
              className="flex items-center justify-center w-10 h-10 rounded-full bg-[#ea4335] hover:bg-[#d33b2c] text-white transition-colors"
              title="Leave meeting"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M3 3a1 1 0 011 1v12a1 1 0 11-2 0V4a1 1 0 011-1zm7.707 3.293a1 1 0 010 1.414L9.414 9H17a1 1 0 110 2H9.414l1.293 1.293a1 1 0 01-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default StudentPage;
