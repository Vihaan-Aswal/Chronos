// src/100ms/VideoClassroom.jsx
import React, { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { HMSRoomProvider, useHMSActions } from "@100mslive/react-sdk";
import Conference from "./Conference";

export default function VideoClassroom() {
  const hmsActions = useHMSActions();
  const [params] = useSearchParams();

  const roomCode = params.get("roomCode");
  const userName = params.get("user");

  useEffect(() => {
    if (!roomCode || !userName) return;

    async function joinRoom() {
      try {
        await hmsActions.join({
          userName,
          authToken: "", // not needed
          roomCode,
        });
      } catch (err) {
        console.error("Join failed:", err);
      }
    }

    joinRoom();
  }, [roomCode, userName]);

  return (
    <HMSRoomProvider>
      <Conference />
    </HMSRoomProvider>
  );
}
