// src/100ms/Conference.jsx
import React from "react";
import {
  useHMSStore,
  useHMSActions,
  selectPeers
} from "@100mslive/react-sdk";

export default function Conference() {
  const hmsActions = useHMSActions();
  const peers = useHMSStore(selectPeers);

  async function toggleMic() {
    const enabled = useHMSStore(s => s.localPeer.audioTrack?.enabled);
    await hmsActions.setLocalAudioEnabled(!enabled);
  }

  async function toggleCam() {
    const enabled = useHMSStore(s => s.localPeer.videoTrack?.enabled);
    await hmsActions.setLocalVideoEnabled(!enabled);
  }

  async function leaveRoom() {
    await hmsActions.leave();
  }

  return (
    <div style={styles.container}>
      <div style={styles.grid}>
        {peers.map(peer => (
          <div key={peer.id} style={styles.tile}>
            <h3>{peer.name}</h3>
            <video
              autoPlay
              playsInline
              ref={ref => {
                if (ref && peer.videoTrack) {
                  hmsActions.attachVideo(peer.videoTrack.id, ref);
                }
              }}
              style={{ width: "100%", borderRadius: "8px" }}
            />
          </div>
        ))}
      </div>

      <div style={styles.controls}>
        <button onClick={toggleMic}>🎤 Mic</button>
        <button onClick={toggleCam}>📷 Cam</button>
        <button onClick={leaveRoom} style={{ background: "red", color: "white" }}>
          Leave
        </button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: "20px",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
    gap: "16px",
  },
  tile: {
    background: "#222",
    padding: "10px",
    borderRadius: "10px",
    color: "white",
  },
  controls: {
    marginTop: "20px",
    display: "flex",
    gap: "10px",
  },
};
